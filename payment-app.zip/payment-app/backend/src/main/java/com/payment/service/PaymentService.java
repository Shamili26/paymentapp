package com.payment.service;

import com.payment.dto.PaymentDto;
import com.payment.exception.*;
import com.payment.model.*;
import com.payment.repository.*;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final AccountRepository accountRepository;
    private final PayeeRepository payeeRepository;
    private final FeeRepository feeRepository;

    // ── Get all payments (Read Replica) ──────────────────────────────────────
    @Transactional(readOnly = true)
    @CircuitBreaker(name = "paymentService", fallbackMethod = "getAllPaymentsFallback")
    public List<PaymentDto.Response> getAllPayments() {
        return paymentRepository.findAllWithDetails()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @SuppressWarnings("unused")
    private List<PaymentDto.Response> getAllPaymentsFallback(Exception ex) {
        log.error("Circuit breaker triggered for getAllPayments: {}", ex.getMessage());
        throw new ServiceUnavailableException("Payment list service temporarily unavailable");
    }

    // ── Get single payment ────────────────────────────────────────────────────
    @Transactional(readOnly = true)
    @CircuitBreaker(name = "paymentService")
    public PaymentDto.Response getPaymentById(Long paymentId) {
        Payment payment = paymentRepository.findByIdWithDetails(paymentId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found: " + paymentId));
        return toResponse(payment);
    }

    // ── Create payment ────────────────────────────────────────────────────────
    @Transactional
    @CircuitBreaker(name = "paymentService")
    @Retry(name = "paymentService")
    public PaymentDto.Response createPayment(PaymentDto.CreateRequest request) {
        // Idempotency check
        String idempotencyKey = request.getIdempotencyKey() != null
                ? request.getIdempotencyKey()
                : UUID.randomUUID().toString();

        if (paymentRepository.existsByIdempotencyKey(idempotencyKey)) {
            throw new DuplicatePaymentException("Duplicate payment request detected");
        }

        Account account = accountRepository.findById(request.getAccountId())
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        if (account.getAccountStatus() != Account.AccountStatus.ACTIVE) {
            throw new BusinessValidationException("Account is not active");
        }

        Payee payee = payeeRepository.findById(request.getPayeeId())
                .orElseThrow(() -> new ResourceNotFoundException("Payee not found"));

        Fee fee = feeRepository.findFeeForAmount(request.getPaymentAmount())
                .orElseThrow(() -> new BusinessValidationException("No fee tier found for amount"));

        Payment payment = Payment.builder()
                .account(account)
                .payee(payee)
                .fee(fee)
                .paymentAmount(request.getPaymentAmount())
                .paymentDate(request.getPaymentDate())
                .memo(request.getMemo())
                .idempotencyKey(idempotencyKey)
                .status(Payment.PaymentStatus.PENDING)
                .build();

        Payment saved = paymentRepository.save(payment);
        log.info("Payment created: id={}, amount={}", saved.getPaymentId(), saved.getPaymentAmount());
        return toResponse(saved);
    }

    // ── Update payment ────────────────────────────────────────────────────────
    @Transactional
    @CircuitBreaker(name = "paymentService")
    public PaymentDto.Response updatePayment(PaymentDto.UpdateRequest request) {
        Payment existing = paymentRepository.findByIdWithDetails(request.getPaymentId())
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found"));

        if (existing.getStatus() == Payment.PaymentStatus.COMPLETED) {
            throw new BusinessValidationException("Completed payments cannot be modified");
        }

        Account account = accountRepository.findById(request.getAccountId())
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        Payee payee = payeeRepository.findById(request.getPayeeId())
                .orElseThrow(() -> new ResourceNotFoundException("Payee not found"));

        Fee fee = feeRepository.findFeeForAmount(request.getPaymentAmount())
                .orElseThrow(() -> new BusinessValidationException("No fee tier found for amount"));

        existing.setAccount(account);
        existing.setPayee(payee);
        existing.setFee(fee);
        existing.setPaymentAmount(request.getPaymentAmount());
        existing.setPaymentDate(request.getPaymentDate());
        existing.setMemo(request.getMemo());

        return toResponse(paymentRepository.save(existing));
    }

    // ── Delete payment ────────────────────────────────────────────────────────
    @Transactional
    public void deletePayment(Long paymentId) {
        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found: " + paymentId));
        paymentRepository.delete(payment);
        log.info("Payment deleted: id={}", paymentId);
    }

    // ── Fee calculator (pure logic, no I/O) ──────────────────────────────────
    @Transactional(readOnly = true)
    public PaymentDto.FeeResponse calculateFee(BigDecimal amount) {
        Fee fee = feeRepository.findFeeForAmount(amount)
                .orElseThrow(() -> new BusinessValidationException("No fee tier found for amount: " + amount));
        return PaymentDto.FeeResponse.builder()
                .paymentAmount(amount)
                .feeAmount(fee.getFeeAmount())
                .feeId(fee.getFeeId())
                .build();
    }

    // ── Account list (for dropdowns) ──────────────────────────────────────────
    @Transactional(readOnly = true)
    public List<PaymentDto.AccountDto> getActiveAccounts() {
        return accountRepository.findByAccountStatus(Account.AccountStatus.ACTIVE)
                .stream()
                .map(a -> PaymentDto.AccountDto.builder()
                        .accountId(a.getAccountId())
                        .accountNumber(a.getAccountNumber())
                        .accountName(a.getAccountName())
                        .accountStatus(a.getAccountStatus().name())
                        .build())
                .collect(Collectors.toList());
    }

    // ── Payee list (for dropdowns) ────────────────────────────────────────────
    @Transactional(readOnly = true)
    public List<PaymentDto.PayeeDto> getAllPayees() {
        return payeeRepository.findAllByOrderByPayeeNameAsc()
                .stream()
                .map(p -> PaymentDto.PayeeDto.builder()
                        .payeeId(p.getPayeeId())
                        .payeeNumber(p.getPayeeNumber())
                        .payeeName(p.getPayeeName())
                        .build())
                .collect(Collectors.toList());
    }

    // ── Response mapper ────────────────────────────────────────────────────────
    private PaymentDto.Response toResponse(Payment p) {
        return PaymentDto.Response.builder()
                .paymentId(p.getPaymentId())
                .accountId(p.getAccount().getAccountId())
                .accountName(p.getAccount().getAccountName())
                .accountNumber(p.getAccount().getAccountNumber())
                .payeeId(p.getPayee().getPayeeId())
                .payeeName(p.getPayee().getPayeeName())
                .payeeNumber(p.getPayee().getPayeeNumber())
                .paymentAmount(p.getPaymentAmount())
                .feeAmount(p.getFee().getFeeAmount())
                .paymentDate(p.getPaymentDate())
                .memo(p.getMemo())
                .status(p.getStatus().name())
                .updatedDatetime(p.getUpdatedDatetime())
                .build();
    }
}
