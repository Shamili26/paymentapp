package com.payment.model;

import lombok.*;
import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "account")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "account_id")
    private Long accountId;

    @Column(name = "account_number", nullable = false, unique = true, length = 20)
    private String accountNumber;

    @Column(name = "account_name", nullable = false, length = 100)
    private String accountName;

    @Column(name = "account_balance", nullable = false, precision = 15, scale = 2)
    private BigDecimal accountBalance;

    @Enumerated(EnumType.STRING)
    @Column(name = "account_status", nullable = false, length = 10)
    private AccountStatus accountStatus;

    @Column(name = "updated_datetime")
    private LocalDateTime updatedDatetime;

    @PrePersist @PreUpdate
    public void prePersist() {
        this.updatedDatetime = LocalDateTime.now();
    }

    public enum AccountStatus { ACTIVE, INACTIVE }
}
