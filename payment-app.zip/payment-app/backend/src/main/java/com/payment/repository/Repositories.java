package com.payment.repository;

import com.payment.model.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {
    List<Account> findByAccountStatus(Account.AccountStatus status);
    Optional<Account> findByAccountNumber(String accountNumber);
}

// ─────────────────────────────────────────────────────────────────────────────

@Repository
interface PayeeRepository extends JpaRepository<Payee, Long> {
    List<Payee> findAllByOrderByPayeeNameAsc();
}

// ─────────────────────────────────────────────────────────────────────────────

@Repository
interface FeeRepository extends JpaRepository<Fee, Long> {

    @Query("SELECT f FROM Fee f WHERE f.amountMin <= :amount " +
           "AND (f.amountMax IS NULL OR f.amountMax >= :amount)")
    Optional<Fee> findFeeForAmount(@Param("amount") BigDecimal amount);
}

// ─────────────────────────────────────────────────────────────────────────────

@Repository
interface PaymentRepository extends JpaRepository<Payment, Long> {

    @Query("SELECT p FROM Payment p JOIN FETCH p.account JOIN FETCH p.payee JOIN FETCH p.fee " +
           "ORDER BY p.updatedDatetime DESC")
    List<Payment> findAllWithDetails();

    @Query("SELECT p FROM Payment p JOIN FETCH p.account JOIN FETCH p.payee JOIN FETCH p.fee " +
           "WHERE p.paymentId = :id")
    Optional<Payment> findByIdWithDetails(@Param("id") Long id);

    boolean existsByIdempotencyKey(String idempotencyKey);
}
