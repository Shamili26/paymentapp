package com.payment.controller;

import com.payment.dto.PaymentDto;
import com.payment.service.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "${cors.allowed-origins}")
public class PaymentController {

    private final PaymentService paymentService;

    // GET /api/payment — list all payments
    @GetMapping("/payment")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
    public ResponseEntity<PaymentDto.ApiResponse<List<PaymentDto.Response>>> getAllPayments() {
        List<PaymentDto.Response> payments = paymentService.getAllPayments();
        return ResponseEntity.ok(PaymentDto.ApiResponse.ok(payments));
    }

    // GET /api/{payment-id}/payment — get specific payment
    @GetMapping("/{paymentId}/payment")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
    public ResponseEntity<PaymentDto.ApiResponse<PaymentDto.Response>> getPaymentById(
            @PathVariable Long paymentId) {
        return ResponseEntity.ok(PaymentDto.ApiResponse.ok(paymentService.getPaymentById(paymentId)));
    }

    // POST /api/payment — create new payment
    @PostMapping("/payment")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
    public ResponseEntity<PaymentDto.ApiResponse<PaymentDto.Response>> createPayment(
            @Valid @RequestBody PaymentDto.CreateRequest request) {
        PaymentDto.Response response = paymentService.createPayment(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(PaymentDto.ApiResponse.ok("Payment created successfully", response));
    }

    // PUT /api/payment — update existing payment
    @PutMapping("/payment")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
    public ResponseEntity<PaymentDto.ApiResponse<PaymentDto.Response>> updatePayment(
            @Valid @RequestBody PaymentDto.UpdateRequest request) {
        return ResponseEntity.ok(PaymentDto.ApiResponse.ok("Payment updated successfully",
                paymentService.updatePayment(request)));
    }

    // DELETE /api/{payment-id}/payment
    @DeleteMapping("/{paymentId}/payment")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<PaymentDto.ApiResponse<Void>> deletePayment(@PathVariable Long paymentId) {
        paymentService.deletePayment(paymentId);
        return ResponseEntity.ok(PaymentDto.ApiResponse.ok("Payment deleted successfully", null));
    }

    // GET /api/payment/fee?amount=5000 — fee calculator
    @GetMapping("/payment/fee")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
    public ResponseEntity<PaymentDto.ApiResponse<PaymentDto.FeeResponse>> calculateFee(
            @RequestParam BigDecimal amount) {
        return ResponseEntity.ok(PaymentDto.ApiResponse.ok(paymentService.calculateFee(amount)));
    }

    // GET /api/accounts — account dropdown
    @GetMapping("/accounts")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
    public ResponseEntity<PaymentDto.ApiResponse<List<PaymentDto.AccountDto>>> getAccounts() {
        return ResponseEntity.ok(PaymentDto.ApiResponse.ok(paymentService.getActiveAccounts()));
    }

    // GET /api/payees — payee dropdown
    @GetMapping("/payees")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
    public ResponseEntity<PaymentDto.ApiResponse<List<PaymentDto.PayeeDto>>> getPayees() {
        return ResponseEntity.ok(PaymentDto.ApiResponse.ok(paymentService.getAllPayees()));
    }

    // GET /health
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("UP");
    }
}
