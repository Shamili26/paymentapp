package com.payment.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import javax.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

// ── Payment Request ──────────────────────────────────────────────────────────
public class PaymentDto {

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class CreateRequest {

        @NotNull(message = "From Account is mandatory")
        private Long accountId;

        @NotNull(message = "To Payee is mandatory")
        private Long payeeId;

        @NotNull(message = "Payment Date is mandatory")
        @FutureOrPresent(message = "Payment Date cannot be in the past")
        @JsonFormat(pattern = "dd/MM/yyyy")
        private LocalDate paymentDate;

        @NotNull(message = "Payment Amount is mandatory")
        @DecimalMin(value = "0.01", message = "Payment Amount must be greater than 0")
        private BigDecimal paymentAmount;

        @Size(max = 100, message = "Memo must be less than 100 characters")
        private String memo;

        private String idempotencyKey;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class UpdateRequest {

        @NotNull(message = "Payment ID is mandatory")
        private Long paymentId;

        @NotNull(message = "From Account is mandatory")
        private Long accountId;

        @NotNull(message = "To Payee is mandatory")
        private Long payeeId;

        @NotNull(message = "Payment Date is mandatory")
        @FutureOrPresent(message = "Payment Date cannot be in the past")
        @JsonFormat(pattern = "dd/MM/yyyy")
        private LocalDate paymentDate;

        @NotNull(message = "Payment Amount is mandatory")
        @DecimalMin(value = "0.01", message = "Payment Amount must be greater than 0")
        private BigDecimal paymentAmount;

        @Size(max = 100, message = "Memo must be less than 100 characters")
        private String memo;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class Response {
        private Long paymentId;
        private Long accountId;
        private String accountName;
        private String accountNumber;
        private Long payeeId;
        private String payeeName;
        private String payeeNumber;
        private BigDecimal paymentAmount;
        private BigDecimal feeAmount;
        @JsonFormat(pattern = "dd/MM/yyyy")
        private LocalDate paymentDate;
        private String memo;
        private String status;
        private LocalDateTime updatedDatetime;
    }

    // Fee calculation response
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class FeeResponse {
        private BigDecimal paymentAmount;
        private BigDecimal feeAmount;
        private Long feeId;
    }

    // Account dropdown item
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class AccountDto {
        private Long accountId;
        private String accountNumber;
        private String accountName;
        private String accountStatus;
    }

    // Payee dropdown item
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class PayeeDto {
        private Long payeeId;
        private String payeeNumber;
        private String payeeName;
    }

    // Auth request / response
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class AuthRequest {
        @NotBlank private String username;
        @NotBlank private String password;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class AuthResponse {
        private String accessToken;
        private String tokenType;
        private long expiresIn;
        private String username;
    }

    // Generic API envelope
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class ApiResponse<T> {
        private boolean success;
        private String message;
        private T data;

        public static <T> ApiResponse<T> ok(T data) {
            return ApiResponse.<T>builder().success(true).data(data).build();
        }

        public static <T> ApiResponse<T> ok(String message, T data) {
            return ApiResponse.<T>builder().success(true).message(message).data(data).build();
        }

        public static <T> ApiResponse<T> error(String message) {
            return ApiResponse.<T>builder().success(false).message(message).build();
        }
    }
}
