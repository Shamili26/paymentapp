-- V1__create_schema.sql
-- Payment Creation System - Initial Schema

CREATE TABLE IF NOT EXISTS account (
    account_id       BIGSERIAL PRIMARY KEY,
    account_number   VARCHAR(20)    NOT NULL UNIQUE,
    account_name     VARCHAR(100)   NOT NULL,
    account_balance  DECIMAL(15,2)  NOT NULL DEFAULT 0.00,
    account_status   VARCHAR(10)    NOT NULL DEFAULT 'ACTIVE'
                         CHECK (account_status IN ('ACTIVE','INACTIVE')),
    updated_datetime TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS payee (
    payee_id         BIGSERIAL PRIMARY KEY,
    payee_number     VARCHAR(20)    NOT NULL UNIQUE,
    payee_name       VARCHAR(100)   NOT NULL,
    amount_due       DECIMAL(15,2)  NOT NULL DEFAULT 0.00,
    due_date         DATE,
    updated_datetime TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS fee (
    fee_id           BIGSERIAL PRIMARY KEY,
    amount_min       DECIMAL(15,2)  NOT NULL,
    amount_max       DECIMAL(15,2),
    fee_amount       DECIMAL(10,2)  NOT NULL,
    updated_datetime TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS payment (
    payment_id       BIGSERIAL PRIMARY KEY,
    account_id       BIGINT         NOT NULL REFERENCES account(account_id),
    payee_id         BIGINT         NOT NULL REFERENCES payee(payee_id),
    fee_id           BIGINT         NOT NULL REFERENCES fee(fee_id),
    payment_amount   DECIMAL(15,2)  NOT NULL CHECK (payment_amount > 0),
    payment_date     DATE           NOT NULL,
    memo             VARCHAR(100),
    status           VARCHAR(10)    NOT NULL DEFAULT 'PENDING'
                         CHECK (status IN ('PENDING','COMPLETED','CANCELLED')),
    idempotency_key  VARCHAR(64)    UNIQUE,
    updated_datetime TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_log (
    log_id           BIGSERIAL PRIMARY KEY,
    entity_type      VARCHAR(50)    NOT NULL,
    entity_id        BIGINT         NOT NULL,
    action           VARCHAR(20)    NOT NULL,
    performed_by     VARCHAR(100),
    performed_at     TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    details          TEXT
);

-- Indexes for performance
CREATE INDEX idx_payment_account ON payment(account_id);
CREATE INDEX idx_payment_payee   ON payment(payee_id);
CREATE INDEX idx_payment_date    ON payment(payment_date);
CREATE INDEX idx_fee_range       ON fee(amount_min, amount_max);
CREATE INDEX idx_audit_entity    ON audit_log(entity_type, entity_id);
