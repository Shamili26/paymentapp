-- V2__seed_data.sql
-- Pre-seed Accounts, Payees, Fee tiers

INSERT INTO account (account_number, account_name, account_balance, account_status) VALUES
('ACC001', 'Rahul Sharma',         150000.00, 'ACTIVE'),
('ACC002', 'Priya Mehta',          80000.00,  'ACTIVE'),
('ACC003', 'Arjun Patel',          250000.00, 'ACTIVE'),
('ACC004', 'Neha Gupta',           45000.00,  'ACTIVE'),
('ACC005', 'Vikram Singh',         320000.00, 'ACTIVE'),
('ACC006', 'Sunita Reddy',         12000.00,  'INACTIVE');

INSERT INTO payee (payee_number, payee_name, amount_due, due_date) VALUES
('JIO001',  'Jio Mobile',          999.00,    '2026-06-30'),
('AIRTEL1', 'Airtel Broadband',    799.00,    '2026-06-25'),
('HDFC001', 'HDFC Credit Card',    15000.00,  '2026-06-20'),
('SBI001',  'SBI Home Loan',       35000.00,  '2026-07-01'),
('BESCOM1', 'BESCOM Electricity',  2400.00,   '2026-06-28'),
('BWSSB1',  'BWSSB Water Bill',    450.00,    '2026-06-22'),
('LIC001',  'LIC Premium',         12000.00,  '2026-07-15'),
('AXIS001', 'Axis Credit Card',    8500.00,   '2026-06-18');

-- Fee tiers as per requirement
INSERT INTO fee (amount_min, amount_max, fee_amount) VALUES
(0.00,     99.99,    10.00),
(100.00,   999.99,   25.00),
(1000.00,  9999.99,  50.00),
(10000.00, 99999.99, 100.00),
(100000.00, NULL,    500.00);
