package com.payment.service;

import com.payment.dto.PaymentDto;
import com.payment.exception.GlobalExceptionHandler.BusinessValidationException;
import com.payment.model.*;
import com.payment.repository.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("PaymentService Unit Tests")
class PaymentServiceTest {

    @Mock private PaymentRepository paymentRepository;
    @Mock private AccountRepository accountRepository;
    @Mock private PayeeRepository payeeRepository;
    @Mock private FeeRepository feeRepository;

    @InjectMocks private PaymentService paymentService;

    private Account mockAccount;
    private Payee mockPayee;
    private Fee mockFee;
    private Payment mockPayment;

    @BeforeEach
    void setUp() {
        mockAccount = Account.builder()
                .accountId(1L).accountNumber("ACC001")
                .accountName("Rahul Sharma")
                .accountBalance(new BigDecimal("150000"))
                .accountStatus(Account.AccountStatus.ACTIVE)
                .build();

        mockPayee = Payee.builder()
                .payeeId(1L).payeeNumber("JIO001").payeeName("Jio Mobile")
                .amountDue(new BigDecimal("999")).build();

        mockFee = Fee.builder()
                .feeId(2L).amountMin(new BigDecimal("100"))
                .amountMax(new BigDecimal("999.99")).feeAmount(new BigDecimal("25"))
                .build();

        mockPayment = Payment.builder()
                .paymentId(1L).account(mockAccount).payee(mockPayee).fee(mockFee)
                .paymentAmount(new BigDecimal("500"))
                .paymentDate(LocalDate.now().plusDays(1))
                .status(Payment.PaymentStatus.PENDING)
                .build();
    }

    // ── getAllPayments ─────────────────────────────────────────────────────────
    @Test
    @DisplayName("getAllPayments returns list successfully")
    void getAllPayments_returnsListSuccessfully() {
        when(paymentRepository.findAllWithDetails()).thenReturn(List.of(mockPayment));

        List<PaymentDto.Response> result = paymentService.getAllPayments();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getPaymentId()).isEqualTo(1L);
        assertThat(result.get(0).getAccountName()).isEqualTo("Rahul Sharma");
        assertThat(result.get(0).getFeeAmount()).isEqualByComparingTo("25");
        verify(paymentRepository).findAllWithDetails();
    }

    @Test
    @DisplayName("getAllPayments returns empty list when no payments")
    void getAllPayments_returnsEmptyList() {
        when(paymentRepository.findAllWithDetails()).thenReturn(Collections.emptyList());
        assertThat(paymentService.getAllPayments()).isEmpty();
    }

    // ── getPaymentById ────────────────────────────────────────────────────────
    @Test
    @DisplayName("getPaymentById returns payment for valid ID")
    void getPaymentById_validId_returnsPayment() {
        when(paymentRepository.findByIdWithDetails(1L)).thenReturn(Optional.of(mockPayment));

        PaymentDto.Response result = paymentService.getPaymentById(1L);

        assertThat(result.getPaymentId()).isEqualTo(1L);
        assertThat(result.getPaymentAmount()).isEqualByComparingTo("500");
    }

    @Test
    @DisplayName("getPaymentById throws ResourceNotFoundException for unknown ID")
    void getPaymentById_unknownId_throwsException() {
        when(paymentRepository.findByIdWithDetails(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> paymentService.getPaymentById(99L))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Payment not found");
    }

    // ── createPayment ─────────────────────────────────────────────────────────
    @Test
    @DisplayName("createPayment succeeds with valid request")
    void createPayment_validRequest_returnsCreatedPayment() {
        PaymentDto.CreateRequest req = PaymentDto.CreateRequest.builder()
                .accountId(1L).payeeId(1L)
                .paymentAmount(new BigDecimal("500"))
                .paymentDate(LocalDate.now().plusDays(1))
                .build();

        when(paymentRepository.existsByIdempotencyKey(any())).thenReturn(false);
        when(accountRepository.findById(1L)).thenReturn(Optional.of(mockAccount));
        when(payeeRepository.findById(1L)).thenReturn(Optional.of(mockPayee));
        when(feeRepository.findFeeForAmount(any())).thenReturn(Optional.of(mockFee));
        when(paymentRepository.save(any())).thenReturn(mockPayment);

        PaymentDto.Response result = paymentService.createPayment(req);

        assertThat(result.getPaymentId()).isEqualTo(1L);
        assertThat(result.getFeeAmount()).isEqualByComparingTo("25");
        verify(paymentRepository).save(any(Payment.class));
    }

    @Test
    @DisplayName("createPayment rejects inactive account")
    void createPayment_inactiveAccount_throwsException() {
        mockAccount.setAccountStatus(Account.AccountStatus.INACTIVE);
        PaymentDto.CreateRequest req = PaymentDto.CreateRequest.builder()
                .accountId(1L).payeeId(1L)
                .paymentAmount(new BigDecimal("500"))
                .paymentDate(LocalDate.now().plusDays(1))
                .build();

        when(paymentRepository.existsByIdempotencyKey(any())).thenReturn(false);
        when(accountRepository.findById(1L)).thenReturn(Optional.of(mockAccount));

        assertThatThrownBy(() -> paymentService.createPayment(req))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("not active");
    }

    @Test
    @DisplayName("createPayment rejects duplicate idempotency key")
    void createPayment_duplicateKey_throwsException() {
        PaymentDto.CreateRequest req = PaymentDto.CreateRequest.builder()
                .accountId(1L).payeeId(1L)
                .paymentAmount(new BigDecimal("500"))
                .paymentDate(LocalDate.now().plusDays(1))
                .idempotencyKey("dup-key-123")
                .build();

        when(paymentRepository.existsByIdempotencyKey("dup-key-123")).thenReturn(true);

        assertThatThrownBy(() -> paymentService.createPayment(req))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Duplicate");
    }

    // ── calculateFee — all 5 tiers ────────────────────────────────────────────
    @Test @DisplayName("calculateFee tier 1: amount < 100 → fee ₹10")
    void calculateFee_tier1() {
        Fee tier1 = Fee.builder().feeId(1L).feeAmount(new BigDecimal("10")).build();
        when(feeRepository.findFeeForAmount(new BigDecimal("50"))).thenReturn(Optional.of(tier1));

        PaymentDto.FeeResponse resp = paymentService.calculateFee(new BigDecimal("50"));
        assertThat(resp.getFeeAmount()).isEqualByComparingTo("10");
    }

    @Test @DisplayName("calculateFee tier 2: 100-999 → fee ₹25")
    void calculateFee_tier2() {
        when(feeRepository.findFeeForAmount(new BigDecimal("500"))).thenReturn(Optional.of(mockFee));

        PaymentDto.FeeResponse resp = paymentService.calculateFee(new BigDecimal("500"));
        assertThat(resp.getFeeAmount()).isEqualByComparingTo("25");
    }

    @Test @DisplayName("calculateFee tier 3: 1000-9999 → fee ₹50")
    void calculateFee_tier3() {
        Fee tier3 = Fee.builder().feeId(3L).feeAmount(new BigDecimal("50")).build();
        when(feeRepository.findFeeForAmount(new BigDecimal("5000"))).thenReturn(Optional.of(tier3));

        PaymentDto.FeeResponse resp = paymentService.calculateFee(new BigDecimal("5000"));
        assertThat(resp.getFeeAmount()).isEqualByComparingTo("50");
    }

    @Test @DisplayName("calculateFee tier 4: 10000-99999 → fee ₹100")
    void calculateFee_tier4() {
        Fee tier4 = Fee.builder().feeId(4L).feeAmount(new BigDecimal("100")).build();
        when(feeRepository.findFeeForAmount(new BigDecimal("50000"))).thenReturn(Optional.of(tier4));

        assertThat(paymentService.calculateFee(new BigDecimal("50000")).getFeeAmount())
                .isEqualByComparingTo("100");
    }

    @Test @DisplayName("calculateFee tier 5: >=100000 → fee ₹500")
    void calculateFee_tier5() {
        Fee tier5 = Fee.builder().feeId(5L).feeAmount(new BigDecimal("500")).build();
        when(feeRepository.findFeeForAmount(new BigDecimal("200000"))).thenReturn(Optional.of(tier5));

        assertThat(paymentService.calculateFee(new BigDecimal("200000")).getFeeAmount())
                .isEqualByComparingTo("500");
    }

    // ── deletePayment ─────────────────────────────────────────────────────────
    @Test
    @DisplayName("deletePayment succeeds for existing payment")
    void deletePayment_success() {
        when(paymentRepository.findById(1L)).thenReturn(Optional.of(mockPayment));
        assertThatCode(() -> paymentService.deletePayment(1L)).doesNotThrowAnyException();
        verify(paymentRepository).delete(mockPayment);
    }

    @Test
    @DisplayName("deletePayment throws for unknown ID")
    void deletePayment_notFound() {
        when(paymentRepository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> paymentService.deletePayment(99L))
                .hasMessageContaining("Payment not found");
    }

    // ── getActiveAccounts ─────────────────────────────────────────────────────
    @Test
    @DisplayName("getActiveAccounts returns only active accounts")
    void getActiveAccounts_returnsActiveOnly() {
        when(accountRepository.findByAccountStatus(Account.AccountStatus.ACTIVE))
                .thenReturn(List.of(mockAccount));

        List<PaymentDto.AccountDto> result = paymentService.getActiveAccounts();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getAccountStatus()).isEqualTo("ACTIVE");
    }

    // ── getAllPayees ──────────────────────────────────────────────────────────
    @Test
    @DisplayName("getAllPayees returns all payees ordered by name")
    void getAllPayees_returnsSorted() {
        when(payeeRepository.findAllByOrderByPayeeNameAsc()).thenReturn(List.of(mockPayee));

        List<PaymentDto.PayeeDto> result = paymentService.getAllPayees();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getPayeeName()).isEqualTo("Jio Mobile");
    }
}
