// App.tsx
import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import {
  AppBar, Toolbar, Typography, Box, Container,
  Button, ThemeProvider, createTheme, CssBaseline, Stepper, Step, StepLabel
} from '@mui/material';
import PaymentIcon from '@mui/icons-material/Payment';
import LogoutIcon from '@mui/icons-material/Logout';
import { Account, Payee, Payment, PaymentFormData } from './types';
import PaymentForm from './components/PaymentForm/PaymentForm';
import PaymentReview from './components/PaymentReview/PaymentReview';
import PaymentConfirmation from './components/PaymentConfirmation/PaymentConfirmation';
import PaymentList from './components/PaymentList/PaymentList';
import { createPayment, getAccounts, getPayees, login } from './services/api';

const theme = createTheme({
  palette: {
    primary: { main: '#1565C0' },
    secondary: { main: '#E8A020' },
  },
  typography: { fontFamily: '"Roboto","Helvetica","Arial",sans-serif' },
});

type Screen = 'login' | 'form' | 'review' | 'confirmation' | 'list';
const STEPS = ['Enter Details', 'Review', 'Confirmation'];

function LoginPage({ onLogin }: { onLogin: () => void }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError]       = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const resp = await login(username, password);
      localStorage.setItem('accessToken', resp.accessToken);
      onLogin();
    } catch {
      setError('Invalid credentials. Try user/user123 or admin/admin123');
    }
  };

  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '80vh' }}>
      <Box component="form" onSubmit={handleLogin} sx={{
        p: 4, border: '1px solid', borderColor: 'divider', borderRadius: 2,
        width: 360, bgcolor: 'background.paper', boxShadow: 3
      }}>
        <Typography variant="h5" fontWeight={700} textAlign="center" mb={3} color="primary">
          Payment System Login
        </Typography>
        {error && <Typography color="error" variant="body2" mb={2}>{error}</Typography>}
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <input
            style={{ padding: '10px', fontSize: '16px', borderRadius: '4px', border: '1px solid #ccc' }}
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <input
            type="password"
            style={{ padding: '10px', fontSize: '16px', borderRadius: '4px', border: '1px solid #ccc' }}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <Button type="submit" variant="contained" size="large" fullWidth>Sign In</Button>
        </Box>
        <Typography variant="caption" color="text.secondary" display="block" mt={2} textAlign="center">
          Demo: user / user123
        </Typography>
      </Box>
    </Box>
  );
}

function PaymentFlow() {
  const [screen, setScreen] = useState<Screen>('list');
  const [formData, setFormData]     = useState<PaymentFormData | null>(null);
  const [createdPayment, setCreated] = useState<Payment | null>(null);
  const [accounts, setAccounts]     = useState<Account[]>([]);
  const [payees, setPayees]         = useState<Payee[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const startNew = async () => {
    const [accs, pays] = await Promise.all([getAccounts(), getPayees()]);
    setAccounts(accs);
    setPayees(pays);
    setFormData(null);
    setScreen('form');
  };

  const handleFormSubmit = (data: PaymentFormData) => {
    setFormData(data);
    setScreen('review');
  };

  const handleConfirm = async () => {
    if (!formData) return;
    setSubmitting(true);
    try {
      const resp = await createPayment({
        accountId:     Number(formData.accountId),
        payeeId:       Number(formData.payeeId),
        paymentDate:   formData.paymentDate,
        paymentAmount: parseFloat(formData.paymentAmount),
        memo:          formData.memo || undefined,
      });
      setCreated(resp);
      setScreen('confirmation');
    } catch (err: any) {
      alert(err?.response?.data?.message || 'Failed to create payment');
    } finally {
      setSubmitting(false);
    }
  };

  const stepIndex = screen === 'form' ? 0 : screen === 'review' ? 1 : 2;

  if (screen === 'list') return <PaymentList onNewPayment={startNew} />;

  return (
    <Box>
      {(screen === 'form' || screen === 'review' || screen === 'confirmation') && (
        <Box sx={{ maxWidth: 700, mx: 'auto', mt: 3, px: 2 }}>
          <Stepper activeStep={stepIndex} alternativeLabel>
            {STEPS.map((label) => (
              <Step key={label}><StepLabel>{label}</StepLabel></Step>
            ))}
          </Stepper>
        </Box>
      )}

      {screen === 'form' && (
        <PaymentForm
          initialData={formData || undefined}
          onSubmit={handleFormSubmit}
        />
      )}
      {screen === 'review' && formData && (
        <PaymentReview
          formData={formData}
          accounts={accounts}
          payees={payees}
          onEdit={() => setScreen('form')}
          onConfirm={handleConfirm}
          submitting={submitting}
        />
      )}
      {screen === 'confirmation' && createdPayment && (
        <PaymentConfirmation
          payment={createdPayment}
          onNewPayment={startNew}
          onViewPayments={() => setScreen('list')}
        />
      )}
    </Box>
  );
}

export default function App() {
  const [loggedIn, setLoggedIn] = useState(!!localStorage.getItem('accessToken'));

  const handleLogout = () => {
    localStorage.removeItem('accessToken');
    setLoggedIn(false);
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AppBar position="static" elevation={1}>
        <Toolbar>
          <PaymentIcon sx={{ mr: 1.5 }} />
          <Typography variant="h6" fontWeight={700} sx={{ flexGrow: 1 }}>
            Payment Creation System
          </Typography>
          {loggedIn && (
            <Button color="inherit" startIcon={<LogoutIcon />} onClick={handleLogout}>
              Logout
            </Button>
          )}
        </Toolbar>
      </AppBar>

      <Container maxWidth="lg" sx={{ py: 2 }}>
        {!loggedIn ? (
          <LoginPage onLogin={() => setLoggedIn(true)} />
        ) : (
          <PaymentFlow />
        )}
      </Container>
    </ThemeProvider>
  );
}
