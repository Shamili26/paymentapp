// types/index.ts

export interface Account {
  accountId: number;
  accountNumber: string;
  accountName: string;
  accountStatus: string;
}

export interface Payee {
  payeeId: number;
  payeeNumber: string;
  payeeName: string;
}

export interface Payment {
  paymentId: number;
  accountId: number;
  accountName: string;
  accountNumber: string;
  payeeId: number;
  payeeName: string;
  payeeNumber: string;
  paymentAmount: number;
  feeAmount: number;
  paymentDate: string;   // DD/MM/YYYY
  memo?: string;
  status: string;
  updatedDatetime: string;
}

export interface FeeResponse {
  paymentAmount: number;
  feeAmount: number;
  feeId: number;
}

export interface PaymentFormData {
  accountId: number | '';
  payeeId: number | '';
  paymentDate: string;
  paymentAmount: string;
  feeAmount: string;
  feeId: number | null;
  memo: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  data: T;
}

export interface AuthResponse {
  accessToken: string;
  tokenType: string;
  expiresIn: number;
  username: string;
}

export interface ValidationErrors {
  accountId?: string;
  payeeId?: string;
  paymentDate?: string;
  paymentAmount?: string;
  memo?: string;
}
