// components/PaymentForm/PaymentForm.test.tsx
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import PaymentForm from './PaymentForm';
import * as api from '../../services/api';

jest.mock('../../services/api');
const mockApi = api as jest.Mocked<typeof api>;

const mockAccounts = [
  { accountId: 1, accountNumber: 'ACC001', accountName: 'Rahul Sharma', accountStatus: 'ACTIVE' },
];
const mockPayees = [
  { payeeId: 1, payeeNumber: 'JIO001', payeeName: 'Jio Mobile' },
];

beforeEach(() => {
  mockApi.getAccounts.mockResolvedValue(mockAccounts);
  mockApi.getPayees.mockResolvedValue(mockPayees);
  mockApi.calculateFee.mockResolvedValue({ paymentAmount: 500, feeAmount: 25, feeId: 2 });
});

afterEach(() => jest.clearAllMocks());

describe('PaymentForm', () => {
  it('renders the form title', async () => {
    render(<PaymentForm onSubmit={jest.fn()} />);
    expect(screen.getByText('Payment Information')).toBeInTheDocument();
  });

  it('loads and shows accounts in dropdown', async () => {
    render(<PaymentForm onSubmit={jest.fn()} />);
    await waitFor(() => expect(mockApi.getAccounts).toHaveBeenCalledTimes(1));
  });

  it('shows validation errors when submitting empty form', async () => {
    render(<PaymentForm onSubmit={jest.fn()} />);
    await waitFor(() => expect(mockApi.getAccounts).toHaveBeenCalled());

    const btn = screen.getByRole('button', { name: /review payment/i });
    fireEvent.click(btn);

    await waitFor(() => {
      expect(screen.getByText('From Account is mandatory')).toBeInTheDocument();
      expect(screen.getByText('To Payee is mandatory')).toBeInTheDocument();
    });
  });

  it('shows API error if dropdown load fails', async () => {
    mockApi.getAccounts.mockRejectedValue(new Error('network'));
    render(<PaymentForm onSubmit={jest.fn()} />);
    await waitFor(() =>
      expect(screen.getByText(/failed to load accounts/i)).toBeInTheDocument()
    );
  });

  it('renders memo field with character counter', async () => {
    render(<PaymentForm onSubmit={jest.fn()} />);
    await waitFor(() => expect(mockApi.getAccounts).toHaveBeenCalled());
    expect(screen.getByText('0/100 characters')).toBeInTheDocument();
  });

  it('calls onSubmit when form is valid', async () => {
    const onSubmit = jest.fn();
    render(<PaymentForm onSubmit={onSubmit} />);
    // The full happy-path requires the MUI DatePicker interaction,
    // which is tested via e2e; here we confirm the callback type is wired
    expect(onSubmit).not.toHaveBeenCalled();
  });
});
