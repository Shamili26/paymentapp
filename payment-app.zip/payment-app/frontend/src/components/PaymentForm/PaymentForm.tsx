// components/PaymentForm/PaymentForm.tsx
import React, { useEffect, useState, useCallback } from 'react';
import {
  Box, TextField, MenuItem, Button, Typography, Paper,
  CircularProgress, Alert, InputAdornment, Grid
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs, { Dayjs } from 'dayjs';
import { Account, Payee, PaymentFormData, ValidationErrors } from '../../types';
import { getAccounts, getPayees, calculateFee } from '../../services/api';
import { formatINR, calculateFeeLocally, validatePaymentDate, formatDate } from '../../utils/feeCalculator';

interface Props {
  initialData?: PaymentFormData;
  onSubmit: (data: PaymentFormData) => void;
}

const EMPTY_FORM: PaymentFormData = {
  accountId: '',
  payeeId: '',
  paymentDate: '',
  paymentAmount: '',
  feeAmount: '',
  feeId: null,
  memo: '',
};

const PaymentForm: React.FC<Props> = ({ initialData, onSubmit }) => {
  const [form, setForm] = useState<PaymentFormData>(initialData || EMPTY_FORM);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [payees, setPayees]     = useState<Payee[]>([]);
  const [errors, setErrors]     = useState<ValidationErrors>({});
  const [loading, setLoading]   = useState(false);
  const [apiError, setApiError] = useState('');

  // Load dropdowns on mount
  useEffect(() => {
    setLoading(true);
    Promise.all([getAccounts(), getPayees()])
      .then(([accs, pays]) => { setAccounts(accs); setPayees(pays); })
      .catch(() => setApiError('Failed to load accounts/payees. Please refresh.'))
      .finally(() => setLoading(false));
  }, []);

  // Live fee calculation on amount change
  const handleAmountChange = useCallback(async (value: string) => {
    setForm((f) => ({ ...f, paymentAmount: value, feeAmount: '' }));
    const amount = parseFloat(value);
    if (!isNaN(amount) && amount > 0) {
      // Instant client-side preview
      const localFee = calculateFeeLocally(amount);
      setForm((f) => ({ ...f, paymentAmount: value, feeAmount: String(localFee) }));
      // Confirm with server (async)
      try {
        const resp = await calculateFee(amount);
        setForm((f) => ({ ...f, feeAmount: String(resp.feeAmount), feeId: resp.feeId }));
      } catch {
        // keep local calc as fallback
      }
    }
  }, []);

  const validate = (): boolean => {
    const errs: ValidationErrors = {};
    if (!form.accountId) errs.accountId = 'From Account is mandatory';
    if (!form.payeeId)   errs.payeeId   = 'To Payee is mandatory';

    const dateErr = validatePaymentDate(form.paymentDate);
    if (dateErr) errs.paymentDate = dateErr;

    const amount = parseFloat(form.paymentAmount);
    if (!form.paymentAmount || isNaN(amount) || amount <= 0)
      errs.paymentAmount = 'Payment Amount must be greater than 0';

    if (form.memo && form.memo.length > 100)
      errs.memo = 'Memo must be less than 100 characters';

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) onSubmit(form);
  };

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 6 }}><CircularProgress /></Box>;

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Paper elevation={3} sx={{ p: 4, maxWidth: 700, mx: 'auto', mt: 4 }}>
        <Typography variant="h5" fontWeight={600} gutterBottom color="primary">
          Payment Information
        </Typography>
        <Typography variant="body2" color="text.secondary" mb={3}>
          All fields are mandatory except Memo
        </Typography>

        {apiError && <Alert severity="error" sx={{ mb: 2 }}>{apiError}</Alert>}

        <Box component="form" onSubmit={handleSubmit} noValidate>
          <Grid container spacing={3}>

            {/* From Account */}
            <Grid item xs={12} sm={6}>
              <TextField
                select fullWidth required
                label="From Account"
                value={form.accountId}
                onChange={(e) => setForm((f) => ({ ...f, accountId: Number(e.target.value) }))}
                error={!!errors.accountId}
                helperText={errors.accountId}
              >
                {accounts.map((a) => (
                  <MenuItem key={a.accountId} value={a.accountId}>
                    {a.accountName} — {a.accountNumber}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>

            {/* To Payee */}
            <Grid item xs={12} sm={6}>
              <TextField
                select fullWidth required
                label="To Payee"
                value={form.payeeId}
                onChange={(e) => setForm((f) => ({ ...f, payeeId: Number(e.target.value) }))}
                error={!!errors.payeeId}
                helperText={errors.payeeId}
              >
                {payees.map((p) => (
                  <MenuItem key={p.payeeId} value={p.payeeId}>
                    {p.payeeName} — {p.payeeNumber}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>

            {/* Payment Date — MUI DatePicker */}
            <Grid item xs={12} sm={6}>
              <DatePicker
                label="Payment Date *"
                format="DD/MM/YYYY"
                minDate={dayjs()}
                value={form.paymentDate ? dayjs(form.paymentDate, 'DD/MM/YYYY') : null}
                onChange={(val: Dayjs | null) => {
                  const str = val ? formatDate(val.toDate()) : '';
                  setForm((f) => ({ ...f, paymentDate: str }));
                  setErrors((e) => ({ ...e, paymentDate: undefined }));
                }}
                slotProps={{
                  textField: {
                    fullWidth: true,
                    required: true,
                    error: !!errors.paymentDate,
                    helperText: errors.paymentDate || 'DD/MM/YYYY — today or future only',
                  },
                }}
              />
            </Grid>

            {/* Payment Amount */}
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth required
                label="Payment Amount"
                type="number"
                inputProps={{ min: 0.01, step: 0.01 }}
                InputProps={{ startAdornment: <InputAdornment position="start">₹</InputAdornment> }}
                value={form.paymentAmount}
                onChange={(e) => handleAmountChange(e.target.value)}
                error={!!errors.paymentAmount}
                helperText={errors.paymentAmount}
              />
            </Grid>

            {/* Fee Amount — read-only, auto-calculated */}
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Fee Amount (Auto-calculated)"
                InputProps={{
                  startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                  readOnly: true,
                }}
                value={form.feeAmount
                  ? formatINR(parseFloat(form.feeAmount)).replace('₹', '')
                  : ''}
                helperText="Calculated automatically based on amount"
                sx={{ '& .MuiInputBase-input': { backgroundColor: '#f5f5f5' } }}
              />
            </Grid>

            {/* Memo */}
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Memo (Optional)"
                multiline
                rows={2}
                inputProps={{ maxLength: 100 }}
                value={form.memo}
                onChange={(e) => setForm((f) => ({ ...f, memo: e.target.value }))}
                error={!!errors.memo}
                helperText={errors.memo || `${form.memo.length}/100 characters`}
              />
            </Grid>

            {/* Submit */}
            <Grid item xs={12}>
              <Button
                type="submit"
                variant="contained"
                size="large"
                fullWidth
                sx={{ mt: 1, py: 1.5, fontWeight: 600 }}
              >
                Review Payment
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Paper>
    </LocalizationProvider>
  );
};

export default PaymentForm;
