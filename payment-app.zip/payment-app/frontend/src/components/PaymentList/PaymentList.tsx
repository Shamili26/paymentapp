// components/PaymentList/PaymentList.tsx
import React, { useEffect, useState } from 'react';
import {
  Box, Paper, Typography, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Chip, Button,
  CircularProgress, Alert, IconButton, Tooltip, TextField
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import SearchIcon from '@mui/icons-material/Search';
import { Payment } from '../../types';
import { getPayments, deletePayment } from '../../services/api';
import { formatINR } from '../../utils/feeCalculator';

interface Props {
  onNewPayment: () => void;
}

const statusColor = (status: string) => {
  if (status === 'COMPLETED') return 'success';
  if (status === 'CANCELLED') return 'error';
  return 'warning';
};

const PaymentList: React.FC<Props> = ({ onNewPayment }) => {
  const [payments, setPayments]   = useState<Payment[]>([]);
  const [filtered, setFiltered]   = useState<Payment[]>([]);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState('');
  const [search, setSearch]       = useState('');

  const load = () => {
    setLoading(true);
    getPayments()
      .then((data) => { setPayments(data); setFiltered(data); })
      .catch(() => setError('Failed to load payments'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  // Client-side search filter
  useEffect(() => {
    const q = search.toLowerCase();
    setFiltered(
      payments.filter(
        (p) =>
          p.accountName.toLowerCase().includes(q) ||
          p.payeeName.toLowerCase().includes(q)  ||
          String(p.paymentId).includes(q)
      )
    );
  }, [search, payments]);

  const handleDelete = async (id: number) => {
    if (!window.confirm(`Delete payment #${id}?`)) return;
    try {
      await deletePayment(id);
      load();
    } catch {
      setError('Failed to delete payment');
    }
  };

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 6 }}><CircularProgress /></Box>;

  return (
    <Box sx={{ maxWidth: 1100, mx: 'auto', mt: 4, px: 2 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h5" fontWeight={600} color="primary">
          Payment Records
        </Typography>
        <Button variant="contained" startIcon={<AddIcon />} onClick={onNewPayment}>
          New Payment
        </Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      <TextField
        placeholder="Search by account, payee or ID…"
        InputProps={{ startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.disabled' }} /> }}
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        size="small"
        sx={{ mb: 2, width: 320 }}
      />

      <TableContainer component={Paper} elevation={2}>
        <Table stickyHeader>
          <TableHead>
            <TableRow sx={{ '& th': { fontWeight: 700, bgcolor: 'primary.main', color: 'white' } }}>
              <TableCell>Txn ID</TableCell>
              <TableCell>From Account</TableCell>
              <TableCell>To Payee</TableCell>
              <TableCell>Date</TableCell>
              <TableCell align="right">Amount</TableCell>
              <TableCell align="right">Fee</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                  No payments found
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((p) => (
                <TableRow key={p.paymentId} hover>
                  <TableCell>#{p.paymentId}</TableCell>
                  <TableCell>{p.accountName}<br />
                    <Typography variant="caption" color="text.secondary">{p.accountNumber}</Typography>
                  </TableCell>
                  <TableCell>{p.payeeName}<br />
                    <Typography variant="caption" color="text.secondary">{p.payeeNumber}</Typography>
                  </TableCell>
                  <TableCell>{p.paymentDate}</TableCell>
                  <TableCell align="right" sx={{ fontWeight: 600 }}>
                    {formatINR(p.paymentAmount)}
                  </TableCell>
                  <TableCell align="right">{formatINR(p.feeAmount)}</TableCell>
                  <TableCell>
                    <Chip label={p.status} color={statusColor(p.status) as any} size="small" />
                  </TableCell>
                  <TableCell>
                    <Tooltip title="Delete">
                      <IconButton size="small" color="error" onClick={() => handleDelete(p.paymentId)}>
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
        Showing {filtered.length} of {payments.length} payments
      </Typography>
    </Box>
  );
};

export default PaymentList;
