// components/PaymentConfirmation/PaymentConfirmation.tsx
import React from 'react';
import { Box, Paper, Typography, Button, Divider, Chip } from '@mui/material';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import ListAltIcon from '@mui/icons-material/ListAlt';
import AddIcon from '@mui/icons-material/Add';
import { Payment } from '../../types';
import { formatINR } from '../../utils/feeCalculator';

interface Props {
  payment: Payment;
  onNewPayment: () => void;
  onViewPayments: () => void;
}

const PaymentConfirmation: React.FC<Props> = ({ payment, onNewPayment, onViewPayments }) => (
  <Paper elevation={3} sx={{ p: 4, maxWidth: 600, mx: 'auto', mt: 4, textAlign: 'center' }}>

    <CheckCircleOutlineIcon sx={{ fontSize: 72, color: 'success.main', mb: 2 }} />

    <Typography variant="h5" fontWeight={700} color="success.main" gutterBottom>
      Payment Successful!
    </Typography>

    <Typography variant="body1" color="text.secondary" mb={3}>
      Your payment has been submitted and assigned a Transaction ID.
    </Typography>

    <Box sx={{
      bgcolor: 'primary.50', border: '2px dashed', borderColor: 'primary.main',
      borderRadius: 2, p: 3, mb: 3
    }}>
      <Typography variant="body2" color="text.secondary">Transaction ID</Typography>
      <Typography variant="h4" fontWeight={800} color="primary">
        #{payment.paymentId}
      </Typography>
    </Box>

    <Divider sx={{ my: 2 }} />

    <Box sx={{ textAlign: 'left', mb: 3 }}>
      {[
        ['From', `${payment.accountName} (${payment.accountNumber})`],
        ['To',   `${payment.payeeName} (${payment.payeeNumber})`],
        ['Date', payment.paymentDate],
        ['Amount', formatINR(payment.paymentAmount)],
        ['Fee', formatINR(payment.feeAmount)],
        ['Total', formatINR(payment.paymentAmount + payment.feeAmount)],
      ].map(([label, val]) => (
        <Box key={label} sx={{ display: 'flex', justifyContent: 'space-between', py: 0.5 }}>
          <Typography variant="body2" color="text.secondary">{label}</Typography>
          <Typography variant="body2" fontWeight={600}>{val}</Typography>
        </Box>
      ))}
    </Box>

    <Chip label={`Status: ${payment.status}`} color="warning" sx={{ mb: 3 }} />

    <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center' }}>
      <Button variant="outlined" startIcon={<ListAltIcon />} onClick={onViewPayments}>
        View All Payments
      </Button>
      <Button variant="contained" startIcon={<AddIcon />} onClick={onNewPayment}>
        New Payment
      </Button>
    </Box>
  </Paper>
);

export default PaymentConfirmation;
