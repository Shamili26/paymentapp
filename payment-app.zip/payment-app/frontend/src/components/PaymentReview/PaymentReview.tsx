// components/PaymentReview/PaymentReview.tsx
import React from 'react';
import {
  Box, Paper, Typography, Divider, Button,
  Table, TableBody, TableCell, TableRow, Chip, Grid
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { Account, Payee, PaymentFormData } from '../../types';
import { formatINR } from '../../utils/feeCalculator';

interface Props {
  formData: PaymentFormData;
  accounts: Account[];
  payees: Payee[];
  onEdit: () => void;
  onConfirm: () => void;
  submitting?: boolean;
}

const PaymentReview: React.FC<Props> = ({
  formData, accounts, payees, onEdit, onConfirm, submitting = false
}) => {
  const account = accounts.find((a) => a.accountId === formData.accountId);
  const payee   = payees.find((p) => p.payeeId === formData.payeeId);

  const rows = [
    { label: 'From Account', value: account ? `${account.accountName} (${account.accountNumber})` : '-' },
    { label: 'To Payee',     value: payee   ? `${payee.payeeName} (${payee.payeeNumber})` : '-' },
    { label: 'Payment Date', value: formData.paymentDate },
    { label: 'Payment Amount', value: formData.paymentAmount ? formatINR(parseFloat(formData.paymentAmount)) : '-' },
    { label: 'Fee Amount',   value: formData.feeAmount ? formatINR(parseFloat(formData.feeAmount)) : '-' },
    { label: 'Memo',         value: formData.memo || '—' },
  ];

  const total = (parseFloat(formData.paymentAmount || '0') + parseFloat(formData.feeAmount || '0'));

  return (
    <Paper elevation={3} sx={{ p: 4, maxWidth: 700, mx: 'auto', mt: 4 }}>
      <Typography variant="h5" fontWeight={600} gutterBottom color="primary">
        Review Payment
      </Typography>
      <Typography variant="body2" color="text.secondary" mb={3}>
        Please verify the details before confirming
      </Typography>

      <Table size="small" sx={{ mb: 3 }}>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.label} sx={{ '&:last-child td': { border: 0 } }}>
              <TableCell sx={{ fontWeight: 600, width: '40%', color: 'text.secondary' }}>
                {row.label}
              </TableCell>
              <TableCell sx={{ fontWeight: 500 }}>{row.value}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <Divider sx={{ my: 2 }} />

      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 3 }}>
        <Box sx={{ textAlign: 'right' }}>
          <Typography variant="body2" color="text.secondary">Total (Amount + Fee)</Typography>
          <Typography variant="h6" fontWeight={700} color="primary">
            {formatINR(total)}
          </Typography>
        </Box>
      </Box>

      <Chip
        label="Pending Confirmation"
        color="warning"
        size="small"
        sx={{ mb: 3 }}
      />

      <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <Button
            variant="outlined"
            size="large"
            fullWidth
            startIcon={<EditIcon />}
            onClick={onEdit}
            disabled={submitting}
          >
            Edit
          </Button>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Button
            variant="contained"
            size="large"
            fullWidth
            startIcon={<CheckCircleIcon />}
            onClick={onConfirm}
            disabled={submitting}
            sx={{ fontWeight: 600 }}
          >
            {submitting ? 'Processing...' : 'Confirm Payment'}
          </Button>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default PaymentReview;
