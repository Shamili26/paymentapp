// utils/feeCalculator.test.ts
import {
  calculateFeeLocally,
  formatINR,
  validatePaymentDate,
  formatDate,
  FEE_TIERS,
} from './feeCalculator';

describe('calculateFeeLocally', () => {
  it('returns ₹10 for amount 0', () => {
    expect(calculateFeeLocally(0)).toBe(10);
  });
  it('returns ₹10 for amount 50 (tier 1: 0-99)', () => {
    expect(calculateFeeLocally(50)).toBe(10);
  });
  it('returns ₹10 for amount 99 (tier 1 boundary)', () => {
    expect(calculateFeeLocally(99)).toBe(10);
  });
  it('returns ₹25 for amount 100 (tier 2 start)', () => {
    expect(calculateFeeLocally(100)).toBe(25);
  });
  it('returns ₹25 for amount 500', () => {
    expect(calculateFeeLocally(500)).toBe(25);
  });
  it('returns ₹25 for amount 999 (tier 2 end)', () => {
    expect(calculateFeeLocally(999)).toBe(25);
  });
  it('returns ₹50 for amount 1000 (tier 3 start)', () => {
    expect(calculateFeeLocally(1000)).toBe(50);
  });
  it('returns ₹50 for amount 5000', () => {
    expect(calculateFeeLocally(5000)).toBe(50);
  });
  it('returns ₹50 for amount 9999 (tier 3 end)', () => {
    expect(calculateFeeLocally(9999)).toBe(50);
  });
  it('returns ₹100 for amount 10000 (tier 4 start)', () => {
    expect(calculateFeeLocally(10000)).toBe(100);
  });
  it('returns ₹100 for amount 99999 (tier 4 end)', () => {
    expect(calculateFeeLocally(99999)).toBe(100);
  });
  it('returns ₹500 for amount 100000 (tier 5 start)', () => {
    expect(calculateFeeLocally(100000)).toBe(500);
  });
  it('returns ₹500 for very large amount', () => {
    expect(calculateFeeLocally(9999999)).toBe(500);
  });
  it('returns 0 for negative amount', () => {
    expect(calculateFeeLocally(-1)).toBe(0);
  });
});

describe('FEE_TIERS', () => {
  it('has exactly 5 tiers', () => {
    expect(FEE_TIERS).toHaveLength(5);
  });
  it('last tier has null max', () => {
    expect(FEE_TIERS[4].max).toBeNull();
  });
});

describe('formatINR', () => {
  it('formats 500 as Indian Rupee', () => {
    expect(formatINR(500)).toContain('500');
    expect(formatINR(500)).toMatch(/[₹]|INR/);
  });
  it('formats 1000 with correct grouping', () => {
    const formatted = formatINR(1000);
    expect(formatted).toContain('1,000');
  });
  it('formats 0 correctly', () => {
    const formatted = formatINR(0);
    expect(formatted).toContain('0');
  });
  it('includes two decimal places', () => {
    expect(formatINR(500)).toContain('00');
  });
});

describe('validatePaymentDate', () => {
  it('returns error for empty string', () => {
    expect(validatePaymentDate('')).toBe('Payment Date is mandatory');
  });
  it('returns error for wrong format', () => {
    expect(validatePaymentDate('2026-06-01')).toBeTruthy();
  });
  it('returns error for past date', () => {
    expect(validatePaymentDate('01/01/2020')).toBe('Payment Date cannot be in the past');
  });
  it('returns null for today', () => {
    const today = formatDate(new Date());
    expect(validatePaymentDate(today)).toBeNull();
  });
  it('returns null for future date', () => {
    const future = new Date();
    future.setDate(future.getDate() + 7);
    expect(validatePaymentDate(formatDate(future))).toBeNull();
  });
  it('returns error for invalid date like 99/99/9999', () => {
    // new Date(9999, 98, 99) → Invalid, isNaN triggers
    const result = validatePaymentDate('99/99/9999');
    expect(result).toBeTruthy();
  });
});

describe('formatDate', () => {
  it('formats date as DD/MM/YYYY', () => {
    const date = new Date(2026, 5, 15); // June 15, 2026
    expect(formatDate(date)).toBe('15/06/2026');
  });
  it('pads single-digit day and month with zero', () => {
    const date = new Date(2026, 0, 5); // Jan 5, 2026
    expect(formatDate(date)).toBe('05/01/2026');
  });
});
