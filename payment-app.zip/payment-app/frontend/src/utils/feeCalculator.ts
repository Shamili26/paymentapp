// utils/feeCalculator.ts

export interface FeeTier {
  min: number;
  max: number | null;
  fee: number;
}

export const FEE_TIERS: FeeTier[] = [
  { min: 0,      max: 99,     fee: 10  },
  { min: 100,    max: 999,    fee: 25  },
  { min: 1000,   max: 9999,   fee: 50  },
  { min: 10000,  max: 99999,  fee: 100 },
  { min: 100000, max: null,   fee: 500 },
];

/**
 * Calculate fee based on payment amount (mirrors server-side logic).
 * Used for instant client-side preview before API call.
 */
export function calculateFeeLocally(amount: number): number {
  if (amount < 0) return 0;
  const tier = FEE_TIERS.find(
    (t) => amount >= t.min && (t.max === null || amount <= t.max)
  );
  return tier ? tier.fee : 0;
}

/** Format amount with Indian Rupee symbol */
export function formatINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
  }).format(amount);
}

/** Validate DD/MM/YYYY format and not in past */
export function validatePaymentDate(dateStr: string): string | null {
  if (!dateStr) return 'Payment Date is mandatory';

  const parts = dateStr.split('/');
  if (parts.length !== 3) return 'Date must be in DD/MM/YYYY format';

  const [day, month, year] = parts.map(Number);
  const date = new Date(year, month - 1, day);

  if (isNaN(date.getTime())) return 'Invalid date';
  if (date < new Date(new Date().setHours(0, 0, 0, 0))) {
    return 'Payment Date cannot be in the past';
  }
  return null;
}

/** Format date to DD/MM/YYYY */
export function formatDate(date: Date): string {
  const d = String(date.getDate()).padStart(2, '0');
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const y = date.getFullYear();
  return `${d}/${m}/${y}`;
}
