// services/api.ts
import axios, { AxiosInstance } from 'axios';
import { Account, ApiResponse, AuthResponse, FeeResponse, Payment, Payee } from '../types';

const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

const apiClient: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
  timeout: 10000,
});

// Request interceptor — attach JWT
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('accessToken');
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor — 401 redirect
apiClient.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('accessToken');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// ── Auth ─────────────────────────────────────────────────────────────────────
export const login = (username: string, password: string): Promise<AuthResponse> =>
  apiClient.post<AuthResponse>('/api/auth/login', { username, password })
    .then((r) => r.data);

export const logout = (): Promise<void> =>
  apiClient.post('/api/auth/logout').then(() => {
    localStorage.removeItem('accessToken');
  });

// ── Payments ─────────────────────────────────────────────────────────────────
export const getPayments = (): Promise<Payment[]> =>
  apiClient.get<ApiResponse<Payment[]>>('/api/payment')
    .then((r) => r.data.data);

export const getPaymentById = (id: number): Promise<Payment> =>
  apiClient.get<ApiResponse<Payment>>(`/api/${id}/payment`)
    .then((r) => r.data.data);

export const createPayment = (payload: {
  accountId: number;
  payeeId: number;
  paymentDate: string;
  paymentAmount: number;
  memo?: string;
  idempotencyKey?: string;
}): Promise<Payment> =>
  apiClient.post<ApiResponse<Payment>>('/api/payment', payload)
    .then((r) => r.data.data);

export const updatePayment = (payload: {
  paymentId: number;
  accountId: number;
  payeeId: number;
  paymentDate: string;
  paymentAmount: number;
  memo?: string;
}): Promise<Payment> =>
  apiClient.put<ApiResponse<Payment>>('/api/payment', payload)
    .then((r) => r.data.data);

export const deletePayment = (id: number): Promise<void> =>
  apiClient.delete(`/api/${id}/payment`).then(() => undefined);

// ── Fee calculation ───────────────────────────────────────────────────────────
export const calculateFee = (amount: number): Promise<FeeResponse> =>
  apiClient.get<ApiResponse<FeeResponse>>(`/api/payment/fee?amount=${amount}`)
    .then((r) => r.data.data);

// ── Dropdowns ─────────────────────────────────────────────────────────────────
export const getAccounts = (): Promise<Account[]> =>
  apiClient.get<ApiResponse<Account[]>>('/api/accounts')
    .then((r) => r.data.data);

export const getPayees = (): Promise<Payee[]> =>
  apiClient.get<ApiResponse<Payee[]>>('/api/payees')
    .then((r) => r.data.data);

export default apiClient;
