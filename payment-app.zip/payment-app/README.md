# Payment Creation System
**Architect Upgrade 2026 | Associate ID 439232**

## Stack
| Layer | Technology |
|---|---|
| Frontend | React.js 18 + TypeScript + MUI v5 |
| Backend | Java 11 + Spring Boot 2.7 |
| Database | PostgreSQL (AWS RDS Multi-AZ) |
| Read Replica | AWS RDS Read Replica |
| Auth | JWT RS256 + Spring Security (Cognito-ready) |
| Token Blacklist | Redis |
| Circuit Breaker | Resilience4j |
| CDN | AWS CloudFront + S3 |
| API Gateway | AWS API Gateway |
| WAF | AWS WAF (OWASP rules) |
| CI/CD | AWS CodePipeline + CodeBuild |
| Coverage | JaCoCo (≥80%) + Jest Istanbul (≥80%) |
| Observability | CloudWatch + X-Ray + CloudTrail |

---

## Quick Start (Local with Docker)

```bash
# Clone and start all services
git clone <repo>
cd payment-app
docker-compose up --build

# Services:
# Frontend  → http://localhost:3000
# Backend   → http://localhost:8080
# Postgres  → localhost:5432
# Redis     → localhost:6379
```

**Demo credentials:** `user / user123` or `admin / admin123`

---

## Run Tests

```bash
# Backend (JUnit 5 + JaCoCo — fails if <80%)
cd backend
mvn clean verify

# Frontend (Jest + Istanbul — fails if <80%)
cd frontend
npm run test:coverage
```

---

## API Endpoints

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| POST | /api/auth/login | Login — returns JWT | Public |
| POST | /api/auth/logout | Blacklists JWT in Redis | Bearer |
| GET | /api/payment | List all payments | ROLE_USER |
| GET | /api/{id}/payment | Get payment by ID | ROLE_USER |
| POST | /api/payment | Create payment | ROLE_USER |
| PUT | /api/payment | Update payment | ROLE_USER |
| DELETE | /api/{id}/payment | Delete payment | ROLE_ADMIN |
| GET | /api/payment/fee?amount=X | Calculate fee | ROLE_USER |
| GET | /api/accounts | Account dropdown | ROLE_USER |
| GET | /api/payees | Payee dropdown | ROLE_USER |
| GET | /api/health | Health check | Public |

---

## Fee Tiers

| Amount (₹) | Fee (₹) |
|---|---|
| 0 – 99 | ₹10 |
| 100 – 999 | ₹25 |
| 1,000 – 9,999 | ₹50 |
| 10,000 – 99,999 | ₹100 |
| 1,00,000+ | ₹500 |

---

## Architecture Notes

- **Frontend → Backend**: All traffic via API Gateway. React has zero direct DB access.
- **Data Access Layer**: RDS in private VPC subnet. Port 5432 open only to Beanstalk security group.
- **Reads** use `@Transactional(readOnly=true)` routed to Read Replica.
- **Writes** use Primary RDS with `@Transactional`.
- **Idempotency**: Each payment POST requires a unique `idempotency_key` — duplicate detection prevents double-payments on retry.
- **Circuit Breaker**: Opens at 50% failure rate over 10 requests; 30s open window.
- **JWT**: 1-hour TTL. Logout blacklists token in Redis with matching TTL.

---

## AWS Deployment

```bash
# Build and push to ECR (handled by CodePipeline)
aws ecr get-login-password --region ap-south-1 | \
  docker login --username AWS --password-stdin <account>.dkr.ecr.ap-south-1.amazonaws.com

# Deploy to Elastic Beanstalk
eb deploy payment-production --label v1.0.0
```

## Chief Architect Review Points Addressed

| Observation | Resolution |
|---|---|
| Deployment Architecture missing | New slide added — VPC/subnet layout, public/private tiers |
| Frontend direct DB access | VPC SG restricts 5432 to App SG only; API Gateway is sole entry |
| Network Details | Added — CIDR, Security Groups, NACLs, WAF |
| AWS Cognito not listed | Added — Cognito User Pool + JWT flow slide |
| Auth process | 4-step flow: Cognito → JWT → API GW Authorizer → Spring RBAC |
| Security Details | Authentication, Data Security, Runtime, Code Security slides |
| Read Replica | `@Transactional(readOnly=true)` routes reads; separate HikariCP pool |
| Test Coverage ≥80% | JaCoCo enforced in `mvn verify`; Jest threshold in `package.json` |
| AWS Amplify removed | Replaced with CodeBuild → S3 → CloudFront pipeline |
| API response ≤3s | JWT verify in-memory, fee calc CPU-only, indexed reads, HikariCP pool |
